from django.apps import AppConfig


class GeografujConfig(AppConfig):
    name = 'geografuj'
