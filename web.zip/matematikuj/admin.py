from django.contrib import admin
from .models import Menu_bloky,Pocetni_priklady,Pocetni_priklady_ZS,Tema_ZS,Tema

class Tema_ZS_Admin(admin.ModelAdmin):
    list_display = ('tema','kapitola')
class Tema_SS_Admin(admin.ModelAdmin):
    list_display = ('tema', 'podtema', 'kapitola')
class Pocetni_priklady_ZS_Admin(admin.ModelAdmin):
    list_display = ('tema','typ', 'rocnik', 'zadani', 'reseni' ) 
class Pocetni_priklady_SS_Admin(admin.ModelAdmin):
    list_display = ('tema','typ', 'zadani', 'reseni' ) 


admin.site.register(Menu_bloky) #registrace databáze
admin.site.register(Tema, Tema_SS_Admin)
admin.site.register(Tema_ZS, Tema_ZS_Admin)
admin.site.register(Pocetni_priklady_ZS, Pocetni_priklady_ZS_Admin)
admin.site.register(Pocetni_priklady, Pocetni_priklady_SS_Admin)

# Register your models here.
