class Strom:
    koren = None
    potomci = []
    def __init__(self, koren, potomci):
        self.koren = koren
        self.potomci = potomci
    
    def __str__(self):
        return self.koren + "\n" + "|-" + self.potomci
         

