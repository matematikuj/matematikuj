from django.apps import AppConfig


class MatematikujConfig(AppConfig):
    name = 'matematikuj'
